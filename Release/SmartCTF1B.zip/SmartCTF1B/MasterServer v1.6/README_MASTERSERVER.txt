Place this folder's contents (minus this file) on your web server running PHP.
You can now point your IpToNation.ini file to your web server for queries.
